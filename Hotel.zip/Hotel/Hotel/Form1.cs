﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hotel
{
    public partial class Form1 : Form
    {
        
        static string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=Hotel;Integrated Security=True;Encrypt=False";
        public Form1()
        {
            InitializeComponent();

            string q1 = "select * from Бронирования";
            string q2 = "select * from Гости";
            string q3 = "select * from Сотрудники";
            string q4 = "select * from Номера";
            string q5 = "select * from Счета";
            string q6 = "select * from Доходы";
            string q7 = "select * from Расходы";
            DataLoad(ref dataAdapterBron, bindingSourceBron, q1, dataGridView1);
            DataLoad(ref dataAdapterGuest, bindingSourceGuest, q2, dataGridView2);
            DataLoad(ref dataAdapterSotr, bindingSourceSotr, q3, dataGridView3);
            DataLoad(ref dataAdapterNum, bindingSourceNum, q4, dataGridView4);
            DataLoad(ref dataAdapterSch, bindingSourceSch, q5, dataGridView5);
            DataLoad(ref dataAdapterD, bindingSourceD, q6, dataGridView6);
            DataLoad(ref dataAdapterR, bindingSourceR, q7, dataGridView7);
        }

        private SqlDataAdapter dataAdapterBron = new SqlDataAdapter();
        private BindingSource bindingSourceBron = new BindingSource();

        private SqlDataAdapter dataAdapterGuest = new SqlDataAdapter();
        private BindingSource bindingSourceGuest = new BindingSource();

        private SqlDataAdapter dataAdapterSotr = new SqlDataAdapter();
        private BindingSource bindingSourceSotr = new BindingSource();

        private SqlDataAdapter dataAdapterNum = new SqlDataAdapter();
        private BindingSource bindingSourceNum = new BindingSource();

        private SqlDataAdapter dataAdapterSch = new SqlDataAdapter();
        private BindingSource bindingSourceSch = new BindingSource();

        private SqlDataAdapter dataAdapterD = new SqlDataAdapter();
        private BindingSource bindingSourceD = new BindingSource();

        private SqlDataAdapter dataAdapterR = new SqlDataAdapter();
        private BindingSource bindingSourceR = new BindingSource();

        private void DataLoad(ref SqlDataAdapter dataAdapter, BindingSource bindingSource, string q, DataGridView dataGridView)
        {
            dataAdapter = new SqlDataAdapter(q, connectionString);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
            // Наполните новую таблицу данных и привяжите ее к источнику BindingSource.
            DataTable table = new DataTable();
            dataAdapter.Fill(table);
            bindingSource.DataSource = table;
            dataGridView.DataSource = bindingSource;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Обновите базу данных с учетом изменений.
            dataAdapterBron.Update((DataTable)bindingSourceBron.DataSource);
            dataAdapterGuest.Update((DataTable)bindingSourceGuest.DataSource);
            dataAdapterSotr.Update((DataTable)bindingSourceSotr.DataSource);
            dataAdapterNum.Update((DataTable)bindingSourceNum.DataSource);
            dataAdapterSch.Update((DataTable)bindingSourceSch.DataSource);
            dataAdapterD.Update((DataTable)bindingSourceD.DataSource);
            dataAdapterR.Update((DataTable)bindingSourceR.DataSource);
        }
    }
}
