﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        public int Admin;
      
        private void button1_Click(object sender, EventArgs e)
        {
            string log = textBox1.Text;
            string pass = textBox2.Text;

            string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=Hotel;Integrated Security=True;Encrypt=False";
            SqlConnection MyConnection = new SqlConnection(connectionString);

            string ComDel = "Select id_сотрудника from Сотрудники where id_сотрудника='" + log + "'";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            string ComDell = "Select пароль from Сотрудники where id_сотрудника='" + log + "'";
            SqlCommand cmd2 = new SqlCommand(ComDell, MyConnection);
            string ComDelll = "Select должность from Сотрудники where id_сотрудника='" + log + "'";
            SqlCommand cmd3 = new SqlCommand(ComDelll, MyConnection);
            MyConnection.Open();

            string a = cmd1.ExecuteScalar().ToString().TrimEnd();
            string b = cmd2.ExecuteScalar().ToString().TrimEnd();
            string c = cmd3.ExecuteScalar().ToString().TrimEnd();

            if (a == log && b == pass)
            {
                Form1 form1 = new Form1();  // создание экземпляра первой формы

                if (c == "администратор")
                {
                    form1.tabPage5.Parent = null;
                    form1.tabPage6.Parent = null;
                }

                if (c == "бухгалтер")
                {
                    form1.tabPage2.Parent = null;
                    form1.tabPage4.Parent = null;
                }

                form1.Owner = this;     // родительской для формы 2 будет текущая форма
                form1.ShowDialog();     // показать окно второй формы в немодальном режиме    
                this.Visible = false;
                this.Enabled = false;
                this.Close();
            }
            else { MessageBox.Show("Неправильный пароль!"); }
            MyConnection.Close();
        }
    }
}
