﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace HotelWeb.Controllers
{
    public class BookingsController : Controller
    {
        private readonly string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=Hotel;Integrated Security=True;Encrypt=False";

        public IActionResult Index()
        {
            var bookings = GetBookings();
            return View(bookings);
        }

        private DataTable GetBookings()
        {
            DataTable table = new DataTable();
            try
            {
               
                string query = "SELECT * FROM Бронирования";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        [HttpPost]
        public IActionResult UpdateBooking(int id_бронирования, string columnName, string newValue)
        {
            try
            {
                string query = $"UPDATE Бронирования SET {columnName} = @newValue WHERE id_бронирования = @id_бронирования";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@newValue", newValue);
                    command.Parameters.AddWithValue("@id_бронирования", id_бронирования);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }

        [HttpPost]
        public IActionResult DeleteBooking(int id_бронирования)
        {
            try
            {
                string query = "DELETE FROM Бронирования WHERE id_бронирования = @id_бронирования";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_бронирования", id_бронирования);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }

        [HttpPost]
        public IActionResult AddBooking(string column1, string column2, string column3)
        {
            try
            {
                string query = "INSERT INTO Бронирования (id_бронирования, id_гостя, id_номера) VALUES (@column1, @column2, @column3)";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@column1", column1);
                    command.Parameters.AddWithValue("@column2", column2);
                    command.Parameters.AddWithValue("@column3", column3);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }
    }
}