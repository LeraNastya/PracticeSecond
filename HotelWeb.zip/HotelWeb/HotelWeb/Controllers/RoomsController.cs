﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace HotelWeb.Controllers
{
    public class RoomsController : Controller
    {
        private readonly string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=Hotel;Integrated Security=True;Encrypt=False";

        public IActionResult Index()
        {
            var rooms = GetRooms();
            return View(rooms);
        }

        private DataTable GetRooms()
        {
            DataTable table = new DataTable();
            try
            {
                string query = "SELECT * FROM Номера";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        [HttpPost]
        public IActionResult UpdateRoom(int id_номера, string columnName, string newValue)
        {
            try
            {
                string query = $"UPDATE Номера SET {columnName} = @newValue WHERE id_номера = @id_номера";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@newValue", newValue);
                    command.Parameters.AddWithValue("@id_номера", id_номера);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }

        [HttpPost]
        public IActionResult DeleteRoom(int id_номера)
        {
            try
            {
                string query = "DELETE FROM Номера WHERE id_номера = @id_номера";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_номера", id_номера);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }

        [HttpPost]
        public IActionResult AddRoom(int id_номера, string тип_номера, string статус_номера, string стоимость)
        {
            try
            {
                string query = "INSERT INTO Номера (id_номера, тип_номера, статус_номера, стоимость) VALUES (@id_номера, @тип_номера, @статус_номера, @стоимость)";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_номера", id_номера);
                    command.Parameters.AddWithValue("@тип_номера", тип_номера);
                    command.Parameters.AddWithValue("@статус_номера", статус_номера);
                    command.Parameters.AddWithValue("@стоимость", стоимость);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }
    }
}