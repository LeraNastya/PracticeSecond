﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace HotelWeb.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=Hotel;Integrated Security=True;Encrypt=False";

        public IActionResult Index()
        {
            var employees = GetEmployees();
            return View(employees);
        }

        private DataTable GetEmployees()
        {
            DataTable table = new DataTable();
            try
            {
                string query = "SELECT * FROM Сотрудники";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        [HttpPost]
        public IActionResult UpdateEmployee(int id_сотрудника, string columnName, string newValue)
        {
            try
            {
                string query = $"UPDATE Сотрудники SET {columnName} = @newValue WHERE id_сотрудника = @id_сотрудника";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@newValue", newValue);
                    command.Parameters.AddWithValue("@id_сотрудника", id_сотрудника);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }

        [HttpPost]
        public IActionResult DeleteEmployee(int id_сотрудника)
        {
            try
            {
                string query = "DELETE FROM Сотрудники WHERE id_сотрудника = @id_сотрудника";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_сотрудника", id_сотрудника);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }

        [HttpPost]
        public IActionResult AddEmployee(int id_сотрудника, string пароль, string ФИО, string Должность, string Зарплата)
        {
            try
            {
                string query = "INSERT INTO Сотрудники (id_сотрудника, пароль, ФИО) VALUES (@id_сотрудника, @пароль, @ФИО)";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_сотрудника", id_сотрудника);
                    command.Parameters.AddWithValue("@пароль", пароль);
                    command.Parameters.AddWithValue("@ФИО", ФИО);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }
    }
}