﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace HotelWeb.Controllers
{
    public class GuestsController : Controller
    {
        private readonly string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=Hotel;Integrated Security=True;Encrypt=False";

        public IActionResult Index()
        {
            var guests = GetGuests();
            return View(guests);
        }

        private DataTable GetGuests()
        {
            DataTable table = new DataTable();
            try
            {
                string query = "SELECT * FROM Гости";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        [HttpPost]
        public IActionResult UpdateGuest(int id_гостя, string columnName, string newValue)
        {
            try
            {
                string query = $"UPDATE Гости SET {columnName} = @newValue WHERE id_гостя = @id_гостя";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@newValue", newValue);
                    command.Parameters.AddWithValue("@id_гостя", id_гостя);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }

        [HttpPost]
        public IActionResult DeleteGuest(int id_гостя)
        {
            try
            {
                string query = "DELETE FROM Гости WHERE id_гостя = @id_гостя";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_гостя", id_гостя);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }

        [HttpPost]
        public IActionResult AddGuest(int id_гостя, string ФИО)
        {
            try
            {
                string query = "INSERT INTO Гости (id_гостя, ФИО) VALUES (@id_гостя, @ФИО)";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_гостя", id_гостя);
                    command.Parameters.AddWithValue("@ФИО", ФИО);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }
    }
}