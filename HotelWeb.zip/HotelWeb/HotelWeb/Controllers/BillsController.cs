﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace HotelWeb.Controllers
{
    public class BillsController : Controller
    {
        private readonly string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=Hotel;Integrated Security=True;Encrypt=False";

        public IActionResult Index()
        {
            var bills = GetBills();
            return View(bills);
        }

        private DataTable GetBills()
        {
            DataTable table = new DataTable();
            try
            {
                string query = "SELECT * FROM Счета";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        [HttpPost]
        public IActionResult UpdateBill(int id_счета, string columnName, string newValue)
        {
            try
            {
                string query = $"UPDATE Счета SET {columnName} = @newValue WHERE id_счета = @id_счета";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@newValue", newValue);
                    command.Parameters.AddWithValue("@id_счета", id_счета);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }

        [HttpPost]
        public IActionResult DeleteBill(int id_счета)
        {
            try
            {
                string query = "DELETE FROM Счета WHERE id_счета = @id_счета";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_счета", id_счета);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }

        [HttpPost]
        public IActionResult AddBill(int id_счета, int id_бронирования)
        {
            try
            {
                string query = "INSERT INTO Счета (id_счета, id_бронирования) VALUES (@id_счета, @id_бронирования)";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_счета", id_счета);
                    command.Parameters.AddWithValue("@id_бронирования", id_бронирования);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }
    }
}