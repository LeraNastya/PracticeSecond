﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace HotelWeb.Controllers
{
    public class IncomesController : Controller
    {
        private readonly string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=Hotel;Integrated Security=True;Encrypt=False";

        public IActionResult Index()
        {
            var incomes = GetIncomes();
            return View(incomes);
        }

        private DataTable GetIncomes()
        {
            DataTable table = new DataTable();
            try
            {
                string query = "SELECT * FROM Доходы";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        [HttpPost]
        public IActionResult UpdateIncome(int id_дохода, string columnName, string newValue)
        {
            try
            {
                string query = $"UPDATE Доходы SET {columnName} = @newValue WHERE id_дохода = @id_дохода";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@newValue", newValue);
                    command.Parameters.AddWithValue("@id_дохода", id_дохода);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }

        [HttpPost]
        public IActionResult DeleteIncome(int id_дохода)
        {
            try
            {
                string query = "DELETE FROM Доходы WHERE id_дохода = @id_дохода";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_дохода", id_дохода);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }

        [HttpPost]
        public IActionResult AddIncome(int id_дохода, string дата, string сумма, string источник)
        {
            try
            {
                string query = "INSERT INTO Доходы (id_дохода, дата, сумма, источник) VALUES (@id_дохода, @дата, @сумма, @источник)";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_дохода", id_дохода);
                    command.Parameters.AddWithValue("@дата", дата);
                    command.Parameters.AddWithValue("@сумма", сумма);
                    command.Parameters.AddWithValue("@источник", источник);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }
    }
}