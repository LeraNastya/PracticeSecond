﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

namespace HotelWeb.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(string login, string password)
        {
            string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=Hotel;Integrated Security=True;Encrypt=False";

            using (SqlConnection MyConnection = new SqlConnection(connectionString))
            {
                try
                {
                    MyConnection.Open();

                    string query = "SELECT id_сотрудника, пароль, должность FROM Сотрудники WHERE id_сотрудника = @Login";
                    using (SqlCommand cmd = new SqlCommand(query, MyConnection))
                    {
                        cmd.Parameters.AddWithValue("@Login", login);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string log = reader["id_сотрудника"].ToString().TrimEnd();
                                string pass = reader["пароль"].ToString().TrimEnd();
                                string role = reader["должность"].ToString().TrimEnd();

                                if (password == pass && login == log)
                                {
                                    if (role == "владелец")
                                    {
                                        HttpContext.Session.SetString("Role", "Owner");
                                    }
                                    else if (role == "администратор")
                                    {
                                        HttpContext.Session.SetString("Role", "Admin");
                                    }
                                    else if (role == "бухгалтер")
                                    {
                                        HttpContext.Session.SetString("Role", "Accountant");
                                    }
                                    else
                                    {
                                        return View();
                                    }

                                    HttpContext.Session.SetString("IsAuthenticated", "true");
                                    return RedirectToAction("Index", "Bookings");
                                }
                                else
                                {
                                    TempData["ErrorMessage"] = "Неверный пароль.";
                                    return View();
                                }
                            }
                            else
                            {
                                TempData["ErrorMessage"] = "Пользователь не найден.";
                                return View();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Обработка исключений
                    TempData["ErrorMessage"] = "Ошибка.";
                    return View();
                }
            }
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Remove("IsAuthenticated");
            HttpContext.Session.Remove("Role");
            return RedirectToAction("Index", "Login");
        }
    }
}
