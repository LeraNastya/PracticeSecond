﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace WebAvia.Controllers
{
    public class ProjectsController : Controller
    {
        string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=AviaFactory;Integrated Security=True;Encrypt=False";

        public IActionResult Index()
        {
            var projects = GetProjects();
            return View(projects);
        }

        public IActionResult Index1()
        {
            var projects = GetProjects();
            return View(projects);
        }

        private DataTable GetProjects()
        {
            DataTable table = new DataTable();
            try
            {
                string query = "SELECT * FROM Проекты";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        [HttpPost]
        public IActionResult UpdateProject(int id_проекта, string columnName, string newValue)
        {
            try
            {
                string query = $"UPDATE Проекты SET {columnName} = @newValue WHERE [Id проекта] = @id_проекта";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@newValue", newValue);
                    command.Parameters.AddWithValue("@id_проекта", id_проекта);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }

        [HttpPost]
        public IActionResult DeleteProject(int id_проекта)
        {
            try
            {
                string query = "DELETE FROM Проекты WHERE [Id проекта] = @id_проекта";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_проекта", id_проекта);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }

        [HttpPost]
        public IActionResult AddProject(int id_проекта, string Название)
        {
            try
            {
                string query = "INSERT INTO Проекты ([Id проекта], Название) VALUES (@id_проекта, @Название)";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_проекта", id_проекта);
                    command.Parameters.AddWithValue("@Название", Название);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = true });
            }
        }
    }
}