﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace WebAvia.Controllers
{
    public class TasksController : Controller
    {
        string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=AviaFactory;Integrated Security=True;Encrypt=False";

        public IActionResult Index()
        {
            var tasks = GetTasks();
            return View(tasks);
        }

        public IActionResult Index1()
        {
            var tasks = GetTasks();
            return View(tasks);
        }

        private DataTable GetTasks()
        {
            DataTable table = new DataTable();
            try
            {
                string query = "SELECT * FROM Задачи";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        [HttpPost]
        public IActionResult UpdateTask(int id_задачи, string columnName, string newValue)
        {
            try
            {
                string query = $"UPDATE Задачи SET [{columnName}] = @newValue WHERE [Id задачи] = @id_задачи";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@newValue", newValue);
                    command.Parameters.AddWithValue("@id_задачи", id_задачи);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false, error = ex.Message });
            }
        }

        [HttpPost]
        public IActionResult DeleteTask(int id_задачи)
        {
            try
            {
                string query = "DELETE FROM Задачи WHERE [Id задачи] = @id_задачи";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_задачи", id_задачи);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false, error = ex.Message });
            }
        }

        [HttpPost]
        public IActionResult AddTask(int id_задачи, string Название, int id_проекта)
        {
            try
            {
                string query = "INSERT INTO Задачи ([Id задачи], Название, [Id проекта]) VALUES (@id_задачи, @Название, @id_проекта)";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_задачи", id_задачи);
                    command.Parameters.AddWithValue("@Название", Название);
                    command.Parameters.AddWithValue("@id_проекта", id_проекта);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false, error = ex.Message });
            }
        }
    }
}