﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace WebAvia.Controllers
{
    public class PositionsController : Controller
    {
        string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=AviaFactory;Integrated Security=True;Encrypt=False";

        public IActionResult Index()
        {
            var positions = GetPositions();
            return View(positions);
        }

        public IActionResult Index1()
        {
            var positions = GetPositions();
            return View(positions);
        }

        private DataTable GetPositions()
        {
            DataTable table = new DataTable();
            try
            {
                string query = "SELECT * FROM Должности";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        [HttpPost]
        public IActionResult UpdatePosition(string название_должности, string columnName, string newValue)
        {
            try
            {
                string query = $"UPDATE Должности SET {columnName} = @newValue WHERE [Название должности] = @название_должности";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@newValue", newValue);
                    command.Parameters.AddWithValue("@название_должности", название_должности);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false });
            }
        }

        [HttpPost]
        public IActionResult DeletePosition(string название_должности)
        {
            try
            {
                string query = "DELETE FROM Должности WHERE [Название должности] = @название_должности";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@название_должности", название_должности);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false });
            }
        }

        [HttpPost]
        public IActionResult AddPosition(string название_должности, string название_отдела)
        {
            try
            {
                string query = "INSERT INTO Должности ([Название должности], [Название отдела]) VALUES (@название_должности, @название_отдела)";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@название_должности", название_должности);
                    command.Parameters.AddWithValue("@название_отдела", название_отдела);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false });
            }
        }
    }
}