﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

namespace WebAvia.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(string login, string password)
        {
            string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=AviaFactory;Integrated Security=True;Encrypt=False";

            using (SqlConnection MyConnection = new SqlConnection(connectionString))
            {
                try
                {
                    MyConnection.Open();

                    string query = "SELECT [Id сотрудника], Пароль, Должность FROM Сотрудники WHERE [Id сотрудника] = @Login";
                    using (SqlCommand cmd = new SqlCommand(query, MyConnection))
                    {
                        cmd.Parameters.AddWithValue("@Login", login);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string log = reader["Id сотрудника"].ToString().TrimEnd();
                                string pass = reader["Пароль"].ToString().TrimEnd();
                                string role = reader["Должность"].ToString().TrimEnd();

                                if (password == pass && login == log)
                                {
                                    if (role == "администратор")
                                    {
                                        HttpContext.Session.SetString("Role", "Admin");
                                        HttpContext.Session.SetString("IsAuthenticated", "true");
                                        return RedirectToAction("Index", "Projects");
                                    }
                                    else if (role == "менеджер по проектам")
                                    {
                                        HttpContext.Session.SetString("Role", "ProgectMagager");
                                        HttpContext.Session.SetString("IsAuthenticated", "true");
                                        return RedirectToAction("Index", "Projects");
                                    }
                                    else
                                    {
                                        HttpContext.Session.SetString("Role", "Other");
                                        HttpContext.Session.SetString("IsAuthenticated", "true");
                                        return RedirectToAction("Index1", "Projects");
                                    }
                                }
                                else
                                {
                                    TempData["ErrorMessage"] = "Неверный пароль.";
                                    return View();
                                }
                            }
                            else
                            {
                                TempData["ErrorMessage"] = "Пользователь не найден.";
                                return View();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Обработка исключений
                    TempData["ErrorMessage"] = "Ошибка." + ex;
                    return View();
                }
            }
        }
    }
}
