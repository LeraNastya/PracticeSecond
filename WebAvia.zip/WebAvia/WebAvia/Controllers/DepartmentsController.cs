﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace WebAvia.Controllers
{
    public class DepartmentsController : Controller
    {
        string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=AviaFactory;Integrated Security=True;Encrypt=False";

        public IActionResult Index()
        {
            var departments = GetDepartments();
            return View(departments);
        }

        public IActionResult Index1()
        {
            var departments = GetDepartments();
            return View(departments);
        }

        private DataTable GetDepartments()
        {
            DataTable table = new DataTable();
            try
            {
                string query = "SELECT * FROM Отделы";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        [HttpPost]
        public IActionResult UpdateDepartment(string название_отдела, string columnName, string newValue)
        {
            try
            {
                string query = $"UPDATE Отделы SET {columnName} = @newValue WHERE [Название отдела] = @название_отдела";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@newValue", newValue);
                    command.Parameters.AddWithValue("@название_отдела", название_отдела);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false });
            }
        }

        [HttpPost]
        public IActionResult DeleteDepartment(string название_отдела)
        {
            try
            {
                string query = "DELETE FROM Отделы WHERE [Название отдела] = @название_отдела";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@название_отдела", название_отдела);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false });
            }
        }

        [HttpPost]
        public IActionResult AddDepartment(string название_отдела)
        {
            try
            {
                string query = "INSERT INTO Отделы ([Название отдела]) VALUES (@название_отдела)";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@название_отдела", название_отдела);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Обработка исключений
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false });
            }
        }
    }
}